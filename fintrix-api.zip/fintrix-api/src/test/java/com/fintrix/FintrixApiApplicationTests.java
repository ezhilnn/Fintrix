package com.fintrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FintrixApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
