package com.fintrix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FintrixApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FintrixApiApplication.class, args);
	}

}
